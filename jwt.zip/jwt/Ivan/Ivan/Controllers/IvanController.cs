﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace Ivan
{
    /// <summary>
    /// 
    /// </summary>
    [Route("ivan")]
    [ApiController]
    public class IvanController : ControllerBase
    {
       /// <summary>
       /// 
       /// </summary>
        public IvanController()
        {

        }

        /// <summary>
        /// 测试接口一
        /// </summary>
        /// <returns></returns>
        [HttpGet("api/value1")]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "hello", "enhajialageiziba" };
        }

        /// <summary>
        /// 测试接口2
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpGet("api/value2")]
        public ActionResult<IEnumerable<string>> Get2()
        {
            var auth = HttpContext.AuthenticateAsync();
            var username = auth.Result.Principal.Claims.First(t => t.Type.Equals(ClaimTypes.Name))?.Value;
            return new string[] { "shazi","enhabobogeidui", username };
        }

        /// <summary>
        /// 测试接口3
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/value3")]
        [Authorize("Permission")]
        public ActionResult<IEnumerable<string>> Get3()
        {
            //这是获取自定义参数的方法
            var auth = HttpContext.AuthenticateAsync().Result.Principal.Claims;
            var userName = auth.FirstOrDefault(t => t.Type.Equals(ClaimTypes.Name))?.Value;
            var role = auth.FirstOrDefault(t => t.Type.Equals("Role"))?.Value;
            return new string[] { "这个接口有管理员权限才可以访问", $"userName={userName}", $"Role={role}" };
        }
    }
}